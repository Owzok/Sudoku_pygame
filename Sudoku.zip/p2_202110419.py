n = int(input())
lst = []
dict = {}
for i in range(n):
    lst.append(input())

for i in lst:
    x = lst.count(i)
    dict[i] = x
    sorted_dict = sorted(dict.items(),key=lambda x:x[1],reverse=True)

print("Output: ")
for k in sorted_dict:
    print(k[0],"=",k[1],"votaciones")