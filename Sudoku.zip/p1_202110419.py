list = [[0,'X',0],['X',0,'X'],[0,'X','X']]

def returnWinner():
    for i in list:
        nuevo_set = set()
        for k in i:
            nuevo_set.add(k)

        #Horizontal
        if len(nuevo_set) == 1:
            for x in nuevo_set:
                print("Output: ")
                print('Gana',x,'en horizontal')
                return

    for i in range(len(list)):
        nuevo_set = set()
        for k in range(len(list)):
            nuevo_set.add(list[k][i])

        if len(nuevo_set) == 1:
            for x in nuevo_set:
                print("Output: ")
                print('Gana',x,'en vertical')
                return

    nuevo_set = set()
    for i in range(len(list)):
        nuevo_set.add(list[i][i])

    if len(nuevo_set) ==1:
        for x in nuevo_set:
            print("Output: ")
            print('Gana',x,'en diagonal')
            return
    
    if (list[0][2] == list[1][1] and list[1][1] == list[2][0]):
            print("Output: ")
            print('Gana',list[0][2],'en diagonal')
            return

    print('Output:')
    print('Empate')

returnWinner()