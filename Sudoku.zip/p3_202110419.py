puzzle =[
    'U','T','E','C',
    '2','0','2','0',
    'C','S','1','1'
    ]
counter = 0

entry = input()
new_puzzle = entry.split(' ')

for i in range(len(new_puzzle)):
    if new_puzzle[i] != puzzle[i]:
        counter +=1

print("Output: \nPiezas que no coinciden:",counter)